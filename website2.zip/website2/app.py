from flask import Flask, redirect, url_for, request, render_template, abort, flash, session
import json
import sqlite3
from passlib.hash import sha256_crypt
from itsdangerous import URLSafeTimedSerializer
from flask import jsonify
import requests
import numpy as np
from functools import wraps
app = Flask(__name__)
app.secret_key = 'random string'
# Flask-Mail is configured


@app.route("/home")
def homepage():
    return render_template("homepage.html")

@app.route("/register", methods = ["POST"])
def register():
    try:
        if request.method == "POST":
            username = request.form['username']
            email = request.form['email']
            password = sha256_crypt.encrypt((str(request.form['password']))) 
            status = "unverified"
            print(username, email, password,status)
            with sqlite3.connect('db/sample.db') as con:
                cur = con.cursor()
                cur.execute("INSERT INTO websiteusers (Username, Email, Password, Status) VALUES (?,?,?,?)", (username,email,password,status) )
                con.commit()
                print(status)
                serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
                token = serializer.dumps(email)
                url = "http://10.223.69.181:5007/sendMail"
                data = {"to":email,"sub":"Verification","msg":"Please verify your mail here: http://127.0.0.1:5002/verification/"+ token,"cc":"Guvvala.HarshaDeep@cognizant.com"}
                requests.post(url,data=data).text
                flash("You are registered. Please check your email for verification.")
                flash("You will be redirected to homepage in 3 seconds...")
                return render_template("register.html")
    except Exception as e:
        return str(e)


def login_required(f):
    @wraps(f)
    def wrap(*args,**kwargs):
        if 'logged_in' in session:
            return f(*args,**kwargs)
        else:
            flash("You need to log in first!")
            return redirect(url_for("login"))
    return wrap


@app.route('/login', methods=["GET","POST"])
def login():
    try:
        if request.method == "POST":
            email = request.form['username']
            print("This is the mail - login:", email)
            with sqlite3.connect('db/sample.db') as con:
                cur = con.cursor()
                x = cur.execute("SELECT * from websiteusers WHERE Email = ?", (email,)).fetchall()
                a,b,x,d,e,f = x[0]
                print("These are the values retrieved from db:", a,b,x,d,e,f)
                print("This is the username/email:", x)
                if sha256_crypt.verify(request.form['password'], x): 
                    session['username'] = email
                    session['logged_in'] = True
                    flash("Hello! Mr."+ a +". You are now logged in")
                    if a == "admin":
                        return render_template("admin.html")
                    else:
                        return render_template("dashboard.html")
                else:
                    #flash("Invalid credentials, try again.")
                    return "invalid"

    except Exception as e:
        return render_template("homepage.html")  

@login_required
@app.route("/logout")
def logout():
    session.clear()
    flash("You are logged out! You will be redirected to homepage in 2 seconds...")
    return render_template("logout.html") 

@app.route("/verification/<token_id>")
def verification(token_id):
    expiration = 3600
    serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    mail_id = serializer.loads(token_id,max_age=expiration)
    print("I have come here", mail_id)
    try:
        with sqlite3.connect('db/sample.db') as con:
            cur = con.cursor()
            x = cur.execute("SELECT * from websiteusers WHERE Email = ?", (mail_id,)).fetchall()
            if int(len(x)) > 0:
                cur.execute("UPDATE websiteusers SET Status = 'verified' WHERE Email = ?", (mail_id,) )
                con.commit()
                flash("Your mail has been verified. Please log in. ")
                return render_template("verification.html")
            else:
                return redirect(url_for("homepage"))

    except Exception as ex:
        return str(ex)

@app.route('/validateemail', methods=['POST'])
def validateemail():
    user_email = request.form['email'] 
    print("I reached here after execution:", user_email)
    with sqlite3.connect('db/sample.db') as con:
        cur = con.cursor()
        x = cur.execute("SELECT * from websiteusers WHERE Email = ?", (user_email,)).fetchall()
        print("The retrived db:", x)
        if int(len(x)) > 0:
            return "invalid"
        else:
            return "valid"

@app.route('/admin', methods = ["GET"])
def admin():
    try:
        if request.method == "GET":
            with sqlite3.connect('db/sample.db') as con:
                cur = con.cursor()
                data = (cur.execute("select (SELECT count(Id) from websiteusers WHERE Status='unverified') as unverified_count,\
                 (SELECT count(Id) from websiteusers WHERE Status ='verified') as verified_count,\
                 (SELECT count(Id) from websiteusers WHERE Gender='Male') as male_count, \
                 (SELECT count(Id) from websiteusers WHERE Gender='Female') as female_count").fetchone())
                print(data)
                stat = [{"status":'unverified', "values" :data[0]},{"status": 'verified', "values": data[1]}]
                gen = [{"gender": 'Male', "values": data[2]} ,{"gender" :'Female', "values":data[3]}] 
                dat = {"stat":stat,"gen":gen}
                print(dat)
                return json.dumps(dat)
    except Exception as ex:
        return str(ex)

if __name__ == '__main__':
   app.run(port = 5002,debug=True)