from flask import Flask, redirect, url_for, request, render_template, abort, flash, session
import json
import sqlite3
from passlib.hash import sha256_crypt
from itsdangerous import URLSafeTimedSerializer
from flask import jsonify
import requests
from functools import wraps
from flask_mail import Mail, Message
app = Flask(__name__)
app.secret_key = 'random string'
# Flask-Mail is configured
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'pittalapaparavu@gmail.com'
app.config['MAIL_PASSWORD'] = 'ilovemybikE@1234'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)

@app.route("/home")
def homepage():
    return render_template("homepage.html")

@app.route("/register", methods = ["POST"])
def register():
    try:
        if request.method == "POST":
            username = request.form['username']
            email = request.form['email']
            password = sha256_crypt.encrypt((str(request.form['password']))) 
            status = "unverified"
            print(username, email, password, status)
            cur.execute("INSERT INTO websiteusers (Username, Email, Password, Status) VALUES (?,?,?,?)", (username,email,password,status) )
            con.commit()
            serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
            token = serializer.dumps(email)
            msg = Message('Hello', sender = 'pittalapaparavu@gmail.com', recipients = [email])
            msg.body = "Please verify your mail here: http://127.0.0.1:5002/verification/"+ token
            mail.send(msg)
            # url = "http://10.223.69.181:5007/sendMail"
            # data = {"to":email,"sub":"Verification","msg":"Please verify your mail here: http://127.0.0.1:5002/verification/"+ token,"cc":"Guvvala.HarshaDeep@cognizant.com"}
            # requests.post(url,data=data).text
            flash("You are registered. Please check your email for verification and login")
            flash("Redirecting you to the homepage!")
            return render_template("register.html")

    except Exception as e:
        return str(e)


def login_required(f):
    @wraps(f)
    def wrap(*args,**kwargs):
        if 'logged_in' in session:
            return f(*args,**kwargs)
        else:
            flash("You need to log in first!")
            return redirect(url_for("login"))
    return wrap

@app.route('/login', methods=["GET","POST"])
def login():
    try:
        if request.method == "POST":
            email = request.form['username']
            print("This is the mail - login:", email)
            with sqlite3.connect('db/sample.db') as con:
                cur = con.cursor()
                x = cur.execute("SELECT * from websiteusers WHERE Email = ?", (email,))
                x = cur.fetchone()[2]
                print("This is the username/email:", x)
                if sha256_crypt.verify(request.form['password'], x): 
                    session['username'] = email
                    session['logged_in'] = True
                    flash("You are now logged in")
                    return render_template("dashboard.html")

                else:
                    # flash("Invalid credentials, try again.")
                    return "invalid"

    except Exception as e:
        return render_template("homepage.html")  


@app.route("/logout")
@login_required
def logout():
    session.clear()
    flash("You are logged out! You will be redirected to homepage in 4 seconds...")
    return render_template("logout.html") 

@app.route("/verification/<token_id>")
def verification(token_id):
    expiration = 3600
    serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    mail_id = serializer.loads(token_id,max_age=expiration)
    print("I have come here", mail_id)
    try:
        with sqlite3.connect('db/sample.db') as con:
            cur = con.cursor()
            x = cur.execute("SELECT * from websiteusers WHERE Email = ?", (mail_id,)).fetchall()
            if int(len(x)) > 0:
                cur.execute("UPDATE websiteusers SET Status = 'verified' WHERE Email = ?", (mail_id,) )
                con.commit()
                flash("Your mail has been verified. Please log in. ")
                return render_template("homepage.html")
            else:
                return render_template("homepage.html")

    except Exception as ex:
        return str(ex)
    
@app.route('/validateemail', methods=['POST'])
def validateemail():
    user_email = request.form['email'] 
    print("I reached here after execution:", user_email)
    with sqlite3.connect('db/sample.db') as con:
        cur = con.cursor()
        x = cur.execute("SELECT * from websiteusers WHERE Email = ?", (user_email,)).fetchall()
        print("The retrived db:", x)
        if int(len(x)) > 0:
            return "invalid"
        else:
            return "valid"

if __name__ == '__main__':
   app.run(port = 5002,debug=True)